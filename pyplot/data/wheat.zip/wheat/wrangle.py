#!/usr/bin/env python
"""
This file creates the meta.json and pandas dataset.csv files from the
dataset.txt file that was downloaded from the UCI machine learning repo.
"""

import os
import json
import pandas as pd

DIRNAME   = os.path.dirname(__file__)
DATAPATH  = os.path.join(DIRNAME, "dataset.txt")
OUTPATH   = os.path.join(DIRNAME, "dataset.csv")

FEATURES  = [
    "area",
    "perimeter",
    "compactness",
    "length",
    "width",
    "asymmetry",
    "groove",
    "label"
]

LABEL_MAP = {
    1: "Kama",
    2: "Rosa",
    3: "Canadian",
}

if __name__ == "__main__":
    df = pd.read_csv(DATAPATH, delimiter='\t', header=None, names=FEATURES)
    for k,v in LABEL_MAP.items():
        df.ix[df.label == k, 'label'] = v
    df.to_csv(OUTPATH, index=False)

    print "Wrote dataset of %i instances and %i attributes to %s" % (df.shape + (OUTPATH,))

    with open('meta.json', 'w') as f:
        meta = {'feature_names': FEATURES, 'target_names': LABEL_MAP}
        json.dump(meta, f, indent=4)
